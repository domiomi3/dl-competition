##### Which track(s) are you participating in? {Fast Networks Track, Large Networks Track, Both}
Fast Networks Track

##### What are the number of learnable parameters in your model?
Fast Networks Track - 90,394
Large Networks Track - N/A

##### Briefly describe your approach
Fast Networks Track - Trained my model using the default training pipeline given in main.py with my custom data augmentation pipeline
Large Networks Track - N/A

##### Command to train your model from scratch
Fast Networks Track - 
```python -m src.main --model MyFastModel --epochs 50 --data-augmentation my_custom_data_augmentation```
Large Networks Track - N/A

##### Command to evaluate your model
Fast Networks Track - 
```python -m src.evaluate_model --model MyFastModel --saved-model-file fast_model --data-augmentations my_evaluation_pipeline```
Large Networks Track - N/A